const express = require("express")

const bodyParser=require("body-parser")

const app = express()

const wx = {
  appid: 'wxbb2c84ae7f68536f',
  secret: '221a9429ec3cc9e41bbb85f29a400955'
}


app.use(bodyParser.json())
app.use(express.static('./media'));

app.post('/',(req,res)=>{
	res.send("post hello world")
})
app.get('/',(req,res)=>{
	res.send("get hello world")
})

app.listen(3000, res => {
  console.log('服务器启动成功，访问地址：http://127.0.0.1:3000/文件名');
});