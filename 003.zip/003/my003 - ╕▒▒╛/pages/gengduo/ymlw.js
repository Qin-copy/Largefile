// pages/gengduo/ymlw.js
Page({
  data: {
    src:"http://localhost:3000/扬名立万.mp4",
  }
})